// Ausgangssoftware des 3. Praktikumsversuchs 
// zur Vorlesung Echtzeit-3D-Computergrahpik
// von Prof. Dr. Alfred Nischwitz
// Programm umgesetzt mit der GLTools Library
#include <iostream>
#ifdef WIN32
#include <windows.h>
#endif

#include <GLTools.h>
#include <GLMatrixStack.h>
#include <GLGeometryTransform.h>
#include <GLFrustum.h>
#include <math.h>
#include <math3d.h>
#include <GL/glut.h>
#include <ImageLoader/ImageLoader.h>
#include <AntTweakBar.h>
#include <iostream>

GLMatrixStack modelViewMatrix;
GLMatrixStack projectionMatrix;


GLGeometryTransform transformPipeline;
GLFrustum viewFrustum;
GLBatch geometryBatch;
GLBatch linesBatch;
GLuint shaders;

/// View space light position
float light_pos[4] = { 0.5f, 0.1f, 5.0f, 1.0f };
/// Lichtfarben
float light_ambient[4] = { 0.0, 0.0, 0.0, 1.0 };
float light_diffuse[4] = { 1.0f, 1.0f, 1.0f, 1.0f };
float light_specular[4] = { 1.0f, 1.0f, 1.0f, 1.0f };

//Materialeigenschaften
float mat_emissive[4] = { 0.0, 0.0, 0.0, 1.0 };
float mat_ambient[4] = { 0.0, 0.0, 0.0, 1.0 };
float mat_diffuse[4] = { 1.0, 1.0, 1.0, 1.0 };
float mat_specular[4] = { 1.0, 1.0, 1.0, 1.0 };
float specular_power = 10;
// Rotationsgroessen
float rotation[] = { 0, 0, 0, 0 };
//GUI
TwBar *bar;


//
const float PI = 3.141592654;
float winkelHalbierende = 1 / sqrt(2);
float xyNormierung = 0.5 * sqrt(3);
float xWerte[8] = { 0, winkelHalbierende, 1, winkelHalbierende, 0, -winkelHalbierende, -1, -winkelHalbierende };
float yWerte[8] = { -1, -winkelHalbierende, 0, winkelHalbierende, 1, winkelHalbierende, 0, -winkelHalbierende };
float angles[8] = { 11 * PI / 8, 9 * PI / 8, 7 * PI / 8, 5 * PI / 8, 3 * PI / 8, PI / 8, 15 * PI / 8, 13 * PI / 8 };

bool normVectorsVisible = false;
int grenzWinkel = 10;
int grenzWinkelTmp = 10;

bool showLinesOnly = false;

//ImageProcessing

GLuint TexId[1];


void InitGUI()
{

	bar = TwNewBar("TweakBar");
	TwDefine(" TweakBar size='200 400'");
	TwAddVarRW(bar, "Model Rotation", TW_TYPE_QUAT4F, &rotation, "");
	TwAddVarRW(bar, "--------------------------------------------------------------------------", TW_TYPE_INT32, &grenzWinkel, "");

	TwAddVarRW(bar, "Light Position", TW_TYPE_DIR3F, &light_pos, "group=Light axisx=-x axisy=-y axisz=-z");
	TwAddVarRW(bar, "Light Ambient", TW_TYPE_COLOR3F, &light_ambient, "group=Light");
	TwAddVarRW(bar, "Light Diffuse", TW_TYPE_COLOR3F, &light_diffuse, "group=Light");
	TwAddVarRW(bar, "Light Specular", TW_TYPE_COLOR3F, &light_specular, "group=Light");

	TwAddVarRW(bar, "-------------------------------------------------------------------------", TW_TYPE_INT32, &grenzWinkel, "");

	TwAddVarRW(bar, "Mat Emissive", TW_TYPE_COLOR3F, &mat_emissive, "group=Mat");
	TwAddVarRW(bar, "Mat Ambient", TW_TYPE_COLOR3F, &mat_ambient, "group=Mat");
	TwAddVarRW(bar, "Mat Diffuse", TW_TYPE_COLOR3F, &mat_diffuse, "group=Mat");
	TwAddVarRW(bar, "Mat Specular", TW_TYPE_COLOR3F, &mat_specular, "group=Mat");
	TwAddVarRW(bar, "------------------------------------------------------------------------", TW_TYPE_INT32, &grenzWinkel, "");


	//Hier weitere GUI Variablen anlegen. F�r Farbe z.B. den Typ TW_TYPE_COLOR4F benutzen
	TwAddVarRW(bar, "Normal-Vektoren sichtbar?", TW_TYPE_BOOLCPP, &normVectorsVisible, "group=Rest");
	TwAddVarRW(bar, "Grenzwinkel:", TW_TYPE_INT32, &grenzWinkel, "group=Rest");
	TwAddVarRW(bar, "Nur linien?", TW_TYPE_BOOLCPP, &showLinesOnly, "group=Rest");





}

// angle < 90
void createDeckel1() {

	for (int i = 0; i < 6; i++) {
		geometryBatch.Normal3f(0, 0, 1);
		geometryBatch.Vertex3f(xWerte[0], yWerte[0], 1);

		linesBatch.Color4f(1, 0, 0, 1);
		linesBatch.Vertex3f(xWerte[0], yWerte[0], 1);
		linesBatch.Vertex3f(xWerte[0], yWerte[0], 2);

		geometryBatch.Normal3f(0, 0, 1);
		geometryBatch.Vertex3f(xWerte[i + 1], yWerte[i + 1], 1);

		linesBatch.Color4f(1, 0, 0, 1);
		linesBatch.Vertex3f(xWerte[i + 1], yWerte[i + 1], 1);
		linesBatch.Vertex3f(xWerte[i + 1], yWerte[i + 1], 2);


		geometryBatch.Normal3f(0, 0, 1);
		geometryBatch.Vertex3f(xWerte[i + 2], yWerte[i + 2], 1);

		linesBatch.Color4f(1, 0, 0, 1);
		linesBatch.Vertex3f(xWerte[i + 2], yWerte[i + 2], 1);
		linesBatch.Vertex3f(xWerte[i + 2], yWerte[i + 2], 2);

	}
}

// angle < 90
void createBoden1() {
	for (int i = 8; i >2; i--) {
		geometryBatch.Normal3f(0, 0, -1);
		geometryBatch.Vertex3f(xWerte[0], yWerte[0], 0);

		linesBatch.Color4f(1, 0, 0, 1);
		linesBatch.Vertex3f(xWerte[0], yWerte[0], 0);
		linesBatch.Vertex3f(xWerte[0], yWerte[0], -1);


		geometryBatch.Normal3f(0, 0, -1);
		geometryBatch.Vertex3f(xWerte[i - 1], yWerte[i - 1], 0);

		linesBatch.Color4f(1, 0, 0, 1);
		linesBatch.Vertex3f(xWerte[i - 1], yWerte[i - 1], 0);
		linesBatch.Vertex3f(xWerte[i - 1], yWerte[i - 1], -1);


		geometryBatch.Normal3f(0, 0, -1);
		geometryBatch.Vertex3f(xWerte[i - 2], yWerte[i - 2], 0);

		linesBatch.Color4f(1, 0, 0, 1);
		linesBatch.Vertex3f(xWerte[i - 2], yWerte[i - 2], 0);
		linesBatch.Vertex3f(xWerte[i - 2], yWerte[i - 2], -1);

	}
}

// angle < 45
void createMantel1() {
	int angleCount = 0;
	for (int i = 8; i >= 1; i--) {

		//
		geometryBatch.Normal3f(cos(angles[angleCount]), sin(angles[angleCount]), 0);
		geometryBatch.MultiTexCoord2f(0, i / 8.0, 0);
		geometryBatch.Vertex3f(xWerte[i % 8], yWerte[i % 8], 0);

		linesBatch.Color4f(1, 0, 0, 1);
		linesBatch.Vertex3f(xWerte[i % 8], yWerte[i % 8], 0);
		linesBatch.Vertex3f(xWerte[i % 8] + cos(angles[angleCount]), yWerte[i % 8] + sin(angles[angleCount]), 0);

		//
		geometryBatch.Normal3f(cos(angles[angleCount]), sin(angles[angleCount]), 0);
		geometryBatch.MultiTexCoord2f(0, i / 8.0, 1);
		geometryBatch.Vertex3f(xWerte[i % 8], yWerte[i % 8], 1);

		linesBatch.Color4f(1, 0, 0, 1);
		linesBatch.Vertex3f(xWerte[i % 8], yWerte[i % 8], 1);
		linesBatch.Vertex3f(xWerte[i % 8] + cos(angles[angleCount]), yWerte[i % 8] + sin(angles[angleCount]), 1);

		//
		geometryBatch.Normal3f(cos(angles[angleCount]), sin(angles[angleCount]), 0);
		geometryBatch.MultiTexCoord2f(0, (i-1) / 8.0, 1);
		geometryBatch.Vertex3f(xWerte[i - 1], yWerte[i - 1], 1);

		linesBatch.Color4f(1, 0, 0, 1);
		linesBatch.Vertex3f(xWerte[i - 1], yWerte[i - 1], 1);
		linesBatch.Vertex3f(xWerte[i - 1] + cos(angles[angleCount]), yWerte[i - 1] + sin(angles[angleCount]), 1);

		//
		geometryBatch.Normal3f(cos(angles[angleCount]), sin(angles[angleCount]), 0);
		geometryBatch.MultiTexCoord2f(0, i / 8.0, 0);
		geometryBatch.Vertex3f(xWerte[i % 8], yWerte[i % 8], 0);

		linesBatch.Color4f(1, 0, 0, 1);
		linesBatch.Vertex3f(xWerte[i % 8], yWerte[i % 8], 0);
		linesBatch.Vertex3f(xWerte[i % 8] + cos(angles[angleCount]), yWerte[i % 8] + sin(angles[angleCount]), 0);

		//
		geometryBatch.Normal3f(cos(angles[angleCount]), sin(angles[angleCount]), 0);
		geometryBatch.MultiTexCoord2f(0, (i - 1) / 8.0, 1);
		geometryBatch.Vertex3f(xWerte[i - 1], yWerte[i - 1], 1);

		linesBatch.Color4f(1, 0, 0, 1);
		linesBatch.Vertex3f(xWerte[i - 1], yWerte[i - 1], 1);
		linesBatch.Vertex3f(xWerte[i - 1] + cos(angles[angleCount]), yWerte[i - 1] + sin(angles[angleCount]), 1);

		//
		geometryBatch.Normal3f(cos(angles[angleCount]), sin(angles[angleCount]), 0);
		geometryBatch.MultiTexCoord2f(0, (i - 1) / 8.0, 0);
		geometryBatch.Vertex3f(xWerte[i - 1], yWerte[i - 1], 0);

		linesBatch.Color4f(1, 0, 0, 1);
		linesBatch.Vertex3f(xWerte[i - 1], yWerte[i - 1], 0);
		linesBatch.Vertex3f(xWerte[i - 1] + cos(angles[angleCount]), yWerte[i - 1] + sin(angles[angleCount]), 0);


		angleCount++;
	}
}

// 45 <= angle < 90
void createMantel2() {
	int angleCount = 0;
	for (int i = 8; i >= 1; i--) {

		//1

		geometryBatch.Normal3f(xWerte[i % 8], yWerte[i % 8], 0);		// Anlegen des Normalenvektors
		geometryBatch.MultiTexCoord2f(0, i / 8.0, 0);					// Anlegen der Texturkoordinate
		geometryBatch.Vertex3f(xWerte[i % 8], yWerte[i % 8], 0);		// Anlegen des Vertex

		linesBatch.Color4f(1, 0, 0, 1);
		linesBatch.Vertex3f(xWerte[i % 8], yWerte[i % 8], 0);
		linesBatch.Vertex3f(xWerte[i % 8] * 2, yWerte[i % 8] * 2, 0);


		//2
		geometryBatch.Normal3f(xWerte[i % 8], yWerte[i % 8], 1);
		geometryBatch.MultiTexCoord2f(0, i / 8.0, 1);
		geometryBatch.Vertex3f(xWerte[i % 8], yWerte[i % 8], 1);

		linesBatch.Color4f(1, 0, 0, 1);
		linesBatch.Vertex3f(xWerte[i % 8], yWerte[i % 8], 1);
		linesBatch.Vertex3f(xWerte[i % 8] * 2, yWerte[i % 8] * 2, 1);


		//3
		geometryBatch.Normal3f(xWerte[i - 1], yWerte[i - 1], 1);
		geometryBatch.MultiTexCoord2f(0, (i - 1) / 8.0, 1);
		geometryBatch.Vertex3f(xWerte[i - 1], yWerte[i - 1], 1);

		linesBatch.Color4f(1, 0, 0, 1);
		linesBatch.Vertex3f(xWerte[i - 1], yWerte[i - 1], 1);
		linesBatch.Vertex3f(xWerte[i - 1] * 2, yWerte[i - 1] * 2, 1);


		//4
		geometryBatch.Normal3f(xWerte[i % 8], yWerte[i % 8], 0);
		geometryBatch.MultiTexCoord2f(0, i / 8.0, 0);
		geometryBatch.Vertex3f(xWerte[i % 8], yWerte[i % 8], 0);

		linesBatch.Color4f(1, 0, 0, 1);
		linesBatch.Vertex3f(xWerte[i % 8], yWerte[i % 8], 0);
		linesBatch.Vertex3f(xWerte[i % 8] * 2, yWerte[i % 8] * 2, 0);


		//5
		geometryBatch.Normal3f(xWerte[i - 1], yWerte[i - 1], 1);
		geometryBatch.MultiTexCoord2f(0, (i - 1) / 8.0, 1);
		geometryBatch.Vertex3f(xWerte[i - 1], yWerte[i - 1], 1);

		linesBatch.Color4f(1, 0, 0, 1);
		linesBatch.Vertex3f(xWerte[i - 1], yWerte[i - 1], 1);
		linesBatch.Vertex3f(xWerte[i - 1] * 2, yWerte[i - 1] * 2, 1);


		//6
		geometryBatch.Normal3f(xWerte[i - 1], yWerte[i - 1], 0);
		geometryBatch.MultiTexCoord2f(0, (i - 1) / 8.0, 0);
		geometryBatch.Vertex3f(xWerte[i - 1], yWerte[i - 1], 0);

		linesBatch.Color4f(1, 0, 0, 1);
		linesBatch.Vertex3f(xWerte[i - 1], yWerte[i - 1], 0);
		linesBatch.Vertex3f(xWerte[i - 1] * 2, yWerte[i - 1] * 2, 0);


		angleCount++;
	}
}


// angle >= 90
void createDeckel2() {
	for (int i = 0; i < 6; i++) {
		geometryBatch.Normal3f(xWerte[0] * xyNormierung, yWerte[0] * xyNormierung, 0.5);
		geometryBatch.Vertex3f(xWerte[0], yWerte[0], 1);

		linesBatch.Color4f(1, 0, 0, 1);
		linesBatch.Vertex3f(xWerte[0], yWerte[0], 1);
		linesBatch.Vertex3f(xWerte[0] + xWerte[0] * xyNormierung, yWerte[0] + yWerte[0] * xyNormierung, 1.5);

		geometryBatch.Normal3f(xWerte[i + 1] * xyNormierung, yWerte[i + 1] * xyNormierung, 0.5);
		geometryBatch.Vertex3f(xWerte[i + 1], yWerte[i + 1], 1);

		linesBatch.Color4f(1, 0, 0, 1);
		linesBatch.Vertex3f(xWerte[i + 1], yWerte[i + 1], 1);
		linesBatch.Vertex3f(xWerte[i + 1] + xWerte[i + 1] * xyNormierung, yWerte[i + 1] + yWerte[i + 1] * xyNormierung, 1.5);


		geometryBatch.Normal3f(xWerte[i + 2] * xyNormierung, yWerte[i + 2] * xyNormierung, 0.5);
		geometryBatch.Vertex3f(xWerte[i + 2], yWerte[i + 2], 1);

		linesBatch.Color4f(1, 0, 0, 1);
		linesBatch.Vertex3f(xWerte[i + 2], yWerte[i + 2], 1);
		linesBatch.Vertex3f(xWerte[i + 2] + xWerte[i + 2] * xyNormierung, yWerte[i + 2] + yWerte[i + 2] * xyNormierung, 1.5);

	}
}

void createBoden2() {
	for (int i = 8; i >2; i--) {
		geometryBatch.Normal3f(xWerte[0] * xyNormierung, yWerte[0] * xyNormierung, -0.5);
		geometryBatch.Vertex3f(xWerte[0], yWerte[0], 0);

		linesBatch.Color4f(1, 0, 0, 1);
		linesBatch.Vertex3f(xWerte[0], yWerte[0], 0);
		linesBatch.Vertex3f(xWerte[0] + xWerte[0] * xyNormierung, yWerte[0] + yWerte[0] * xyNormierung, -0.5);


		geometryBatch.Normal3f(xWerte[i - 1] * xyNormierung, yWerte[i - 1] * xyNormierung, -0.5);
		geometryBatch.Vertex3f(xWerte[i - 1], yWerte[i - 1], 0);

		linesBatch.Color4f(1, 0, 0, 1);
		linesBatch.Vertex3f(xWerte[i - 1], yWerte[i - 1], 0);
		linesBatch.Vertex3f(xWerte[i - 1] + xWerte[i - 1] * xyNormierung, yWerte[i - 1] + yWerte[i - 1] * xyNormierung, -0.5);


		geometryBatch.Normal3f(xWerte[i - 2] * xyNormierung, yWerte[i - 2] * xyNormierung, -0.5);
		geometryBatch.Vertex3f(xWerte[i - 2], yWerte[i - 2], 0);

		linesBatch.Color4f(1, 0, 0, 1);
		linesBatch.Vertex3f(xWerte[i - 2], yWerte[i - 2], 0);
		linesBatch.Vertex3f(xWerte[i - 2] + xWerte[i - 2] * xyNormierung, yWerte[i - 2] + yWerte[i - 2] * xyNormierung, -0.5);

	}
}

void createMantel3() {
	int angleCount = 0;
	for (int i = 8; i >= 1; i--) {

		geometryBatch.Normal3f(xWerte[i % 8] * xyNormierung, yWerte[i % 8] * xyNormierung, -0.5);
		geometryBatch.MultiTexCoord2f(0, i / 8.0, 0);
		geometryBatch.Vertex3f(xWerte[i % 8], yWerte[i % 8], 0);

		linesBatch.Color4f(1, 0, 0, 1);
		linesBatch.Vertex3f(xWerte[i % 8], yWerte[i % 8], 0);
		linesBatch.Vertex3f(xWerte[i % 8] + xWerte[i % 8] * xyNormierung, yWerte[i % 8] + yWerte[i % 8] * xyNormierung, -0.5);



		geometryBatch.Normal3f(xWerte[i % 8] * xyNormierung, yWerte[i % 8] * xyNormierung, 1.5);
		geometryBatch.MultiTexCoord2f(0, i / 8.0, 1);
		geometryBatch.Vertex3f(xWerte[i % 8], yWerte[i % 8], 1);

		linesBatch.Color4f(1, 0, 0, 1);
		linesBatch.Vertex3f(xWerte[i % 8], yWerte[i % 8], 1);
		linesBatch.Vertex3f(xWerte[i % 8] + xWerte[i % 8] * xyNormierung, yWerte[i % 8] + yWerte[i % 8] * xyNormierung, 1.5);



		geometryBatch.Normal3f(xWerte[i - 1] * xyNormierung, yWerte[i - 1] * xyNormierung, 1.5);
		geometryBatch.MultiTexCoord2f(0, (i - 1) / 8.0, 1);
		geometryBatch.Vertex3f(xWerte[i - 1], yWerte[i - 1], 1);

		linesBatch.Color4f(1, 0, 0, 1);
		linesBatch.Vertex3f(xWerte[i - 1], yWerte[i - 1], 1);
		linesBatch.Vertex3f(xWerte[i - 1] + xWerte[i - 1] * xyNormierung, yWerte[i - 1] + yWerte[i - 1] * xyNormierung, 1.5);



		geometryBatch.Normal3f(xWerte[i % 8] * xyNormierung, yWerte[i % 8] * xyNormierung, -0.5);
		geometryBatch.MultiTexCoord2f(0, i / 8.0, 0);
		geometryBatch.Vertex3f(xWerte[i % 8], yWerte[i % 8], 0);

		linesBatch.Color4f(1, 0, 0, 1);
		linesBatch.Vertex3f(xWerte[i % 8], yWerte[i % 8], 0);
		linesBatch.Vertex3f(xWerte[i % 8] + xWerte[i % 8] * xyNormierung, yWerte[i % 8] + yWerte[i % 8] * xyNormierung, -0.5);



		geometryBatch.Normal3f(xWerte[i - 1] * xyNormierung, yWerte[i - 1] * xyNormierung, 1.5);
		geometryBatch.MultiTexCoord2f(0, (i - 1) / 8.0, 1);
		geometryBatch.Vertex3f(xWerte[i - 1], yWerte[i - 1], 1);

		linesBatch.Color4f(1, 0, 0, 1);
		linesBatch.Vertex3f(xWerte[i - 1], yWerte[i - 1], 1);
		linesBatch.Vertex3f(xWerte[i - 1] + xWerte[i - 1] * xyNormierung, yWerte[i - 1] + yWerte[i - 1] * xyNormierung, 1.5);



		geometryBatch.Normal3f(xWerte[i - 1] * xyNormierung, yWerte[i - 1] * xyNormierung, -0.5);
		geometryBatch.MultiTexCoord2f(0, (i - 1) / 8.0, 0);
		geometryBatch.Vertex3f(xWerte[i - 1], yWerte[i - 1], 0);

		linesBatch.Color4f(1, 0, 0, 1);
		linesBatch.Vertex3f(xWerte[i - 1], yWerte[i - 1], 0);
		linesBatch.Vertex3f(xWerte[i - 1] + xWerte[i - 1] * xyNormierung, yWerte[i - 1] + yWerte[i - 1] * xyNormierung, -0.5);


		angleCount++;
	}
}

void createZylinder1() {
	createDeckel1();

	createMantel1();

	createBoden1();
}

void createZylinder2() {
	createDeckel1();

	createMantel2();

	createBoden1();
}

void createZylinder3() {
	createDeckel2();

	createMantel3();

	createBoden2();
}

void CreateGeometry() {
	geometryBatch.Reset();
	linesBatch.Reset();

	//Dreieck (18 f�r Deckel, 18 f�r Boden, 48 f�r Mantel
	geometryBatch.Begin(GL_TRIANGLES, 84, 1);
	linesBatch.Begin(GL_LINES, 84 * 2);



	if (grenzWinkel < 45)
		createZylinder1();
	else if (grenzWinkel < 90)
		createZylinder2();
	else
		createZylinder3();

	linesBatch.End();
	geometryBatch.End();

	//Shader Programme laden. Die letzen Argumente geben die Shader-Attribute an. Hier wird Vertex und Normale gebraucht.
	shaders = gltLoadShaderPairWithAttributes("VertexShader.glsl", "FragmentShader.glsl", 3,
		GLT_ATTRIBUTE_VERTEX, "vVertex",
		GLT_ATTRIBUTE_NORMAL, "vNormal",
		GLT_ATTRIBUTE_TEXTURE0, "vTexCoord");

	gltCheckErrors(shaders);

	/*
	for (int i = 0; i < 8; i++) {
	std::cout << "cos: " << cos(angles[i]) << " sin: " << sin(angles[i]) << " l�nge: " << sqrt(cos(angles[i]) * cos(angles[i]) + sin(angles[i]) * sin(angles[i])) << std::endl;
	}
	*/
}



// Aufruf draw scene
void RenderScene(void)
{
	if (grenzWinkel != grenzWinkelTmp) {
		grenzWinkelTmp = grenzWinkel;
		CreateGeometry();
	}

	// Clearbefehle f�r den color buffer und den depth buffer
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	glEnable(GL_DEPTH_TEST);
	modelViewMatrix.LoadIdentity();
	modelViewMatrix.Translate(0, 0, -5);
	// Speichere den matrix state und f�hre die Rotation durch
	modelViewMatrix.PushMatrix();

	M3DMatrix44f rot;
	m3dQuatToRotationMatrix(rot, rotation);
	modelViewMatrix.MultMatrix(rot);

	glBindTexture(GL_TEXTURE_2D, TexId[0]);

	//setze den Shader f�r das Rendern
	glUseProgram(shaders);
	// Matrizen an den Shader �bergeben
	glUniformMatrix4fv(glGetUniformLocation(shaders, "mvpMatrix"), 1, GL_FALSE, transformPipeline.GetModelViewProjectionMatrix());
	glUniformMatrix4fv(glGetUniformLocation(shaders, "mvMatrix"), 1, GL_FALSE, transformPipeline.GetModelViewMatrix());
	glUniformMatrix3fv(glGetUniformLocation(shaders, "normalMatrix"), 1, GL_FALSE, transformPipeline.GetNormalMatrix(true));
	// Lichteigenschaften �bergeben
	glUniform4fv(glGetUniformLocation(shaders, "light_pos_vs"), 1, light_pos);
	glUniform4fv(glGetUniformLocation(shaders, "light_ambient"), 1, light_ambient);
	glUniform4fv(glGetUniformLocation(shaders, "light_diffuse"), 1, light_diffuse);
	glUniform4fv(glGetUniformLocation(shaders, "light_specular"), 1, light_specular);
	glUniform1f(glGetUniformLocation(shaders, "spec_power"), specular_power);
	//Materialeigenschaften �bergeben
	glUniform4fv(glGetUniformLocation(shaders, "mat_emissive"), 1, mat_emissive);
	glUniform4fv(glGetUniformLocation(shaders, "mat_ambient"), 1, mat_ambient);
	glUniform4fv(glGetUniformLocation(shaders, "mat_diffuse"), 1, mat_diffuse);
	glUniform4fv(glGetUniformLocation(shaders, "mat_specular"), 1, mat_specular);
	//Zeichne Model
	if (!showLinesOnly)
		geometryBatch.Draw();
	if (normVectorsVisible)
		linesBatch.Draw();

	// Hole die im Stack gespeicherten Transformationsmatrizen wieder zur�ck
	modelViewMatrix.PopMatrix();
	// Draw tweak bars
	TwDraw();
	gltCheckErrors(shaders);
	// Vertausche Front- und Backbuffer
	glutSwapBuffers();
	glutPostRedisplay();
}

void initImageLoader() {
	img::ImageLoader imgLoader;

	glGenTextures(1, TexId);

	glBindTexture(GL_TEXTURE_2D, TexId[0]);

	int width, height, type, internalformat;
	bool jpg;
	//Textur einlesen. Bei JPEG bildern das topdown flag auf true setzen, sonst stehen die Bilder auf den Kopf.
	jpg = false;
	type = GL_BGR;
	internalformat = GL_RGB;
	
	unsigned char* data = imgLoader.LoadTextureFromFile("../Texturen/e43_color_1280_720.bmp", &width, &height, jpg);

	//Textur hochladen, bei JPEG bildern muss GL_BGR verwendet werden
	glTexImage2D(GL_TEXTURE_2D, 0, internalformat, width, height,
		0, type, GL_UNSIGNED_BYTE, data);

	delete[] data;

	//Zugriffsflags setzen, wichtig!
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);

	/*
	glBindTexture(GL_TEXTURE_2D, TexId[0]);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
	*/

}


// Initialisierung des Rendering Kontextes
void SetupRC()
{
	// Schwarzer Hintergrund
	glClearColor(0.12f, 0.35f, 0.674f, 0.0f);

	// In Uhrzeigerrichtung zeigende Polygone sind die Vorderseiten.
	// Dies ist umgekehrt als bei der Default-Einstellung weil wir Triangle_Fans ben�tzen
	glFrontFace(GL_CCW);

	transformPipeline.SetMatrixStacks(modelViewMatrix, projectionMatrix);

	//NEU
	initImageLoader();
	//NEU

	//erzeuge die geometrie
	CreateGeometry();
	InitGUI();
}

void ShutDownRC()
{
	glDeleteProgram(shaders);
	TwTerminate();
}



void ChangeSize(int w, int h)
{
	// Verhindere eine Division durch Null
	if (h == 0)
		h = 1;
	// Setze den Viewport gemaess der Window-Groesse
	glViewport(0, 0, w, h);
	// Ruecksetzung des Projection matrix stack
	projectionMatrix.LoadIdentity();
	viewFrustum.SetPerspective(45, w / (float)h, 1, 100);
	projectionMatrix.LoadMatrix(viewFrustum.GetProjectionMatrix());
	// Ruecksetzung des Model view matrix stack
	modelViewMatrix.LoadIdentity();

	// Send the new window size to AntTweakBar
	TwWindowSize(w, h);
}

int main(int argc, char* argv[])
{
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
	glutInitWindowSize(800, 600);
	glutCreateWindow("A3 Normalenvektoren");
	atexit(ShutDownRC);

	GLenum err = glewInit();
	if (GLEW_OK != err)
	{
		//Veralteter Treiber etc.
		std::cerr << "Error: " << glewGetErrorString(err) << "\n";
		return 1;
	}
	glutMouseFunc((GLUTmousebuttonfun)TwEventMouseButtonGLUT);
	glutMotionFunc((GLUTmousemotionfun)TwEventMouseMotionGLUT);
	glutPassiveMotionFunc((GLUTmousemotionfun)TwEventMouseMotionGLUT); // same as MouseMotion
	glutKeyboardFunc((GLUTkeyboardfun)TwEventKeyboardGLUT);
	glutSpecialFunc((GLUTspecialfun)TwEventKeyboardGLUT);

	glutReshapeFunc(ChangeSize);
	glutDisplayFunc(RenderScene);
	TwInit(TW_OPENGL, NULL);
	SetupRC();
	glutMainLoop();
	ShutDownRC();
	return 0;
}
